define(["text!./task-purpose-add.html", "./task-purpose-add", "text!./task-purpose-add.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});