define(["text!./review-file-identifier-create.html", "./review-file-identifier-create", "text!./review-file-identifier-create.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});