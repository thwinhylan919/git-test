define(["text!./review-file-identifier.html", "./review-file-identifier", "text!./review-file-identifier.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});