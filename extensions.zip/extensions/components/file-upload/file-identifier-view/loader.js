define(["text!./file-identifier-view.html", "./file-identifier-view", "text!./file-identifier-view.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});