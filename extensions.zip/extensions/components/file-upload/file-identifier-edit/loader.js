define(["text!./file-identifier-edit.html", "./file-identifier-edit", "text!./file-identifier-edit.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});