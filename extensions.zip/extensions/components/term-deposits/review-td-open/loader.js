define(["text!./review-td-open.html", "./review-td-open", "text!./review-td-open.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});