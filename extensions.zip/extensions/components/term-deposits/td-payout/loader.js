define(["text!./td-payout.html", "./td-payout", "text!./td-payout.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});