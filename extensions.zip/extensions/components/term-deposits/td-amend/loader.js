define(["text!./td-amend.html", "./td-amend", "text!./td-amend.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});