define(["text!./review-quick-recharge.html", "./review-quick-recharge", "text!./review-quick-recharge.json"], function(template, viewModel) {
  "use strict";

  return {
    viewModel: viewModel,
    template: template
  };
});