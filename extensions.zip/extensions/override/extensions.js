define([], function() {
    "use strict";

    return {
        // eslint-disable-next-line no-unused-vars
        evaluateSegment: function(roles, defaultSegment) {
            return null;
        },
        // eslint-disable-next-line no-unused-vars
        evaluateContext: function(segment, roles) {
            return null;
        },
        // eslint-disable-next-line no-unused-vars
        init: function() {
            return null;
        },
        // eslint-disable-next-line no-unused-vars
        getCurrencyFormattingOptions: function(currency) {
            return null;
        }
    };
});